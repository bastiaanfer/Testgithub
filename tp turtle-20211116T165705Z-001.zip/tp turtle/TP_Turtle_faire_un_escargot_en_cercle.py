import turtle, random

maTurtle = turtle.Turtle()
maTurtle.speed(0)

while True:
    maTurtle.forward(5)
    a=random.randint(1.3)
    
    if a==1:
        maTurtle.left(90)
        
    elif a==2:
        maTurtle.forward(0)

    else :
        maTurtle.right(90)