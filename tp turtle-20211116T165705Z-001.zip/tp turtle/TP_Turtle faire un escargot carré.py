import turtle

maTurtle = turtle.Turtle()

rayon=100

for i in range(25):

    maTurtle.forward(3*i )
    maTurtle.left(90)
    maTurtle.speed(5)

input()