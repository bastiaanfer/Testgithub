import turtle

maTurtle = turtle.Turtle()

rayon=100

for i in range(25):

    maTurtle.circle(rayon + i,50 )
    

input()

