import turtle

maTurtle = turtle.Turtle()

maTurtle.forward (50)
maTurtle.left(90)
maTurtle.forward(50)
maTurtle.left(90)
maTurtle.forward(50)
maTurtle.left(90)
maTurtle.forward(50)


input()