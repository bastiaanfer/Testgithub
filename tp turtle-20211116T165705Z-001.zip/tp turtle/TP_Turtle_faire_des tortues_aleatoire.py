import turtle, random
from typing import List

turtle.delay(0)

n= 2 # nombre de bot-tortues

def move_forward():
    maTurtle.forward(10)

def move_left():
    maTurtle.left(90)

def move_right():
    maTurtle.right(90)

def move_backward():
    maTurtle.backward(90)


tortuesListe=[]
for i in range(2):
    
    botTurtle = turtle.Turtle()
    botTurtle.speed(1)
    botTurtle.color(random.random(),random.random(),random.random())
    botTurtle.shape("circle")
    tortuesListe.append(botTurtle)
    
maTurtle= turtle.Turtle()
maTurtle.color("red")
turtle.onkey(move_forward,'z')
turtle.onkey(move_backward,'s')
turtle.onkey(move_left,'q')
turtle.onkey(move_right,'d')
maTurtle.speed(2)

    
while True:
    for i in tortuesListe:
        i.forward(5)
        a=random.randint(1,3)
        
        if a==1:
            i.left(90)
            
        elif a==2:
            i.forward(0)

        else :
            i.right(90)
        
