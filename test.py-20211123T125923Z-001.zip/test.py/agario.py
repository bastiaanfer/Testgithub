import turtle,random

turtle.delay(0)

maTurtle= turtle.Turtle()
maTurtle.color(random.random(),random.random(),random.random())
maTurtle.shape("circle")
maTurtle.hideturtle()
maTurtle.isvisible()
False
maTurtle.showturtle()
maTurtle.isvisible()
True

maTurtle.turtlesize() 
def is_collided_with(a, b):
    return abs(a.xcor() - b.xcor()) < 10 and abs(a.ycor() - b.ycor()) < 10

def move_forward():
    maTurtle.forward(10)

def move_left():
    maTurtle.left(90)
    maTurtle.forward(10)

def move_right():
    maTurtle.right(90)
    maTurtle.forward(10)

def move_backward():
    maTurtle.backward(10)

turtle.onkey(move_forward,'z')
turtle.onkey(move_backward,'s')
turtle.onkey(move_left,'q')
turtle.onkey(move_right,'d')

turtle.listen()

maTurtle.speed(0)

# FIN DE LA PROGRAMTION DE maTurtle

# PROGRAME DES botTurtle

# nombre de bot-tortues

n=2 

tortuesListe=[]
for i in range(2):
    
    botTurtle = turtle.Turtle()
    botTurtle.speed(1)
    botTurtle.color(random.random(),random.random(),random.random())
    botTurtle.shape("circle")
    tortuesListe.append(botTurtle)

def is_collided_with(a, b):
        return abs(a.xcor() - b.xcor()) < 10 and abs(a.ycor() - b.ycor()) < 10     
    
while True:
    for i in tortuesListe:
        i.forward(5)
        a=random.randint(1,3)
        
        if a==1:
            i.left(90)
            
        elif a==2:
            i.forward(0)

        else :
            i.right(90)

    if tortuesListe[0] and tortuesListe[1]  and is_collided_with(tortuesListe[0],tortuesListe[1]):
    
        if tortuesListe[0].turtlesize()>tortuesListe[1].turtlesize():
            tortuesListe[0].turtlesize(tortuesListe[0].turtlesize()+tortuesListe[1].turtlesize())
            del tortuesListe[1]

        if tortuesListe[0].turtlesize()<tortuesListe[1].turtlesize():
            tortuesListe[1].turtlesize(tortuesListe[1].turtlesize()+tortuesListe[0].turtlesize())
            del tortuesListe[0]

    if tortuesListe[0] and maTurtle and is_collided_with(tortuesListe[0],tortuesListe[1]):
        
        if tortuesListe[0].turtlesize()>maTurtle.turtlesize():
            tortuesListe[0].turtlesize(tortuesListe[0].turtlesize()+maTurtle.turtlesize())
            del maTurtle

        if tortuesListe[0].turtlesize()<maTurtle.turtlesize():
            maTurtle.turtlesize(maTurtle.turtlesize()+tortuesListe[0].turtlesize())
            del tortuesListe[0]

    if tortuesListe[1] and maTurtle and is_collided_with(tortuesListe[0],tortuesListe[1]):
        
        if tortuesListe[1].turtlesize()>maTurtle.turtlesize():
            tortuesListe[1].turtlesize(tortuesListe[1].turtlesize()+maTurtle.turtlesize())
            del tortuesListe[1]

        if tortuesListe[1].turtlesize()<maTurtle.turtlesize():
            maTurtle.turtlesize(maTurtle.turtlesize()+tortuesListe[1].turtlesize())
            del tortuesListe[1]

    

